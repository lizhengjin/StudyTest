//
//  Facade.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Facade.h"
#import "SubSystemOne.h"
#import "SubSystemTwo.h"
#import "SubSystemThree.h"
#import "SubSystemFour.h"
@interface Facade ()
@property   (nonatomic, strong) SubSystemOne   *one;
@property   (nonatomic, strong) SubSystemTwo   *two;
@property   (nonatomic, strong) SubSystemThree *three;
@property   (nonatomic, strong) SubSystemFour  *four;
@end
@implementation Facade
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.one = [[SubSystemOne alloc] init];
        self.two = [[SubSystemTwo alloc] init];
        self.three = [[SubSystemThree alloc] init];
        self.four = [[SubSystemFour alloc] init];
    }
    return self;
}
- (void)methodA
{
    [self.one methodOne];
    [self.two methodTwo];
    [self.four methodFour];
}
- (void)methodB
{
    [self.two methodTwo];
    [self.three methodThree];
    [self.four methodFour];
}
@end
