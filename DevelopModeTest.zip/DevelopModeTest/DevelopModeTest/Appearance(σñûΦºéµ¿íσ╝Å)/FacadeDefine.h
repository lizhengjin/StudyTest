//
//  FacadeDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#ifndef FacadeDefine_h
#define FacadeDefine_h

#import "SubSystemOne.h"
#import "SubSystemTwo.h"
#import "SubSystemThree.h"
#import "SubSystemFour.h"
#import "Facade.h"
#endif /* FacadeDefine_h */
