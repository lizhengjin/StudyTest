//
//  SubSystemTwo.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "SubSystemTwo.h"

@implementation SubSystemTwo
- (void)methodTwo
{
    NSLog(@"methodTwo");
}
@end
