//
//  SubSystemOne.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "SubSystemOne.h"

@implementation SubSystemOne
- (void)methodOne
{
    NSLog(@"methodOne");
}
@end
