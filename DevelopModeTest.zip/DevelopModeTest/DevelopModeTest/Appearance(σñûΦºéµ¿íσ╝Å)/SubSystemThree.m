//
//  SubSystemThree.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "SubSystemThree.h"

@implementation SubSystemThree
- (void)methodThree
{
    NSLog(@"methodThree");
}
@end
