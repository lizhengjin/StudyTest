//
//  SubSystemFour.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "SubSystemFour.h"

@implementation SubSystemFour
- (void)methodFour
{
    NSLog(@"methodFour");
}
@end
