//
//  SubSystemTwo.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SubSystemTwo : NSObject
- (void)methodTwo;
@end

NS_ASSUME_NONNULL_END
