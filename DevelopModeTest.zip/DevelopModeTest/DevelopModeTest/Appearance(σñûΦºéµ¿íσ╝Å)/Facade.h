//
//  Facade.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Facade : NSObject
- (void)methodA;
- (void)methodB;
@end

NS_ASSUME_NONNULL_END
