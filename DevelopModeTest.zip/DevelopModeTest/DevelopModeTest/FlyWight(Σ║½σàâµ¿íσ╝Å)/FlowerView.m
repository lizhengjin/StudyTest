//
//  FlowerView.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "FlowerView.h"

@implementation FlowerView

- (void)drawRect:(CGRect)rect
{
    [self.image drawInRect:rect];
}

@end
