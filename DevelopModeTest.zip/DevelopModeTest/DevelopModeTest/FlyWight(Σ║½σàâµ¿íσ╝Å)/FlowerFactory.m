//
//  FlowerFactory.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "FlowerFactory.h"
#import "FlowerView.h"
@implementation FlowerFactory
- (UIView *)flowerViewWithType:(FlowerType)type
{
    UIView *flowerView = [self.flowerPool objectForKey:[NSNumber numberWithInt:type]];
    if (flowerView == nil) {
        UIImage *flowerImage;
        switch (type) {
            case kAnemone:
                flowerImage = [UIImage imageNamed:@""];
                break;
            case kCosmos:
                flowerImage = [UIImage imageNamed:@""];
                break;
            case kGerberas:
                flowerImage = [UIImage imageNamed:@""];
                break;
            case kHollyhock:
                flowerImage = [UIImage imageNamed:@""];
                break;
            case kJasmine:
                flowerImage = [UIImage imageNamed:@""];
                break;
            default:
                break;
        }
        flowerView = [[FlowerView alloc] initWithImage:flowerImage];
        [self.flowerPool setObject:flowerView forKey:[NSNumber numberWithInt:type]];
    }
    return flowerView;
}
- (NSMutableDictionary *)flowerPool
{
    if (!_flowerPool) {
        _flowerPool = [[NSMutableDictionary alloc] initWithCapacity:kTotalNumberOfFlowerTypes];
    }
    return _flowerPool;
}
@end
