//
//  FlowerFactory.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

/*
 用6种花的图样画500朵花
 
 */
typedef NS_ENUM(NSUInteger, FlowerType) {
    kAnemone,
    kCosmos,
    kGerberas,
    kHollyhock,
    kJasmine,
    kZinnia,
    kTotalNumberOfFlowerTypes
};
@interface FlowerFactory : NSObject
@property   (nonatomic, strong) NSMutableDictionary *flowerPool;
- (UIView *)flowerViewWithType:(FlowerType)type;
@end

NS_ASSUME_NONNULL_END
