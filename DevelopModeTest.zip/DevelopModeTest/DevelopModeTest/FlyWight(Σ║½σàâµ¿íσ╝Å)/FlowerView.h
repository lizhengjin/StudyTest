//
//  FlowerView.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FlowerView : UIImageView
- (void)drawRect:(CGRect)rect;
@end

NS_ASSUME_NONNULL_END
