//
//  SceneDelegate.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

