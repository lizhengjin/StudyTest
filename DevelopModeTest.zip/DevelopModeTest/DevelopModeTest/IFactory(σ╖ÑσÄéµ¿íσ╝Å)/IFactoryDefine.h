//
//  IFactoryDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#ifndef IFactoryDefine_h
#define IFactoryDefine_h

#import "LeiFeng.h"
#import "IFactory.h"
#import "UndergraduateFactory.h"
#import "VolunteerFactory.h"
#endif /* IFactoryDefine_h */
