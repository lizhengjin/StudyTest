//
//  IFactory.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/14.
//

#import <Foundation/Foundation.h>
#import "LeiFeng.h"
NS_ASSUME_NONNULL_BEGIN

@interface IFactory : NSObject
@property  (nonatomic, strong) LeiFeng *leiFeng;
- (LeiFeng *)createLeiFeng;
@end

NS_ASSUME_NONNULL_END
