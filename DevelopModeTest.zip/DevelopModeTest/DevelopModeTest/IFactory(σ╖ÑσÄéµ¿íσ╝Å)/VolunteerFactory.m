//
//  VolunteerFactory.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/14.
//

#import "VolunteerFactory.h"

@implementation VolunteerFactory
- (LeiFeng *)createLeiFeng
{
    if (!self.leiFeng) {
        LeiFeng *leiFeng = [[LeiFeng alloc] init];
        self.leiFeng = leiFeng;
    }
    return self.leiFeng;
}
@end
