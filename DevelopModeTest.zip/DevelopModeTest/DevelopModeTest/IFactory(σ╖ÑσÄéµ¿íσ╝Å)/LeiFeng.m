//
//  LeiFeng.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/14.
//

#import "LeiFeng.h"

@implementation LeiFeng
- (void)sweep
{
    NSLog(@"sweep");
}
- (void)wash
{
    NSLog(@"wash");
}
- (void)buyRice
{
    NSLog(@"buyRice");
}
@end
