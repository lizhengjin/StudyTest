//
//  UndergraduateFactory.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/14.
//

#import "UndergraduateFactory.h"

@implementation UndergraduateFactory
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.leiFeng = [[LeiFeng alloc] init];
    }
    return self;
}
- (LeiFeng *)createLeiFeng
{
//    if (!self.leiFeng) {
//        LeiFeng *leiFeng = [[LeiFeng alloc] init];
//        self.leiFeng = leiFeng;
//    }
    return self.leiFeng;
}

@end
