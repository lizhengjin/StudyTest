//
//  VolunteerFactory.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/14.
//

#import "IFactory.h"

NS_ASSUME_NONNULL_BEGIN

@interface VolunteerFactory : IFactory

@end

NS_ASSUME_NONNULL_END
