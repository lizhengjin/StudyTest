//
//  StrategyDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#ifndef StrategyDefine_h
#define StrategyDefine_h
#import "Strategy.h"
#import "ConcreteStrategyA.h"
#import "ConcreteStrategyB.h"
#import "ConcreteStrategyC.h"
#import "Context.h"
#endif /* StrategyDefine_h */
