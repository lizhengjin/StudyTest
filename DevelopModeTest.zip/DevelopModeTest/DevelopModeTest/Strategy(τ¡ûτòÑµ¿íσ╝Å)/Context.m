//
//  Context.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Context.h"

@implementation Context
- (void)contextStrategy:(Strategy *)strategy
{
    self.strategy = strategy;
}
- (void)contextInterface
{
    [self.strategy algorithmInterface];
}
@end
