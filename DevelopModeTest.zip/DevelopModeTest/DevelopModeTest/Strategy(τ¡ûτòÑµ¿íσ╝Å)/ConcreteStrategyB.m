//
//  ConcreteStrategyB.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "ConcreteStrategyB.h"

@implementation ConcreteStrategyB
- (void)algorithmInterface
{
    NSLog(@"ConcreteStrategyB 实现");
}
@end
