//
//  Context.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import <Foundation/Foundation.h>
#import "Strategy.h"
NS_ASSUME_NONNULL_BEGIN

@interface Context : NSObject
@property  (nonatomic, strong) Strategy *strategy;
- (void)contextStrategy:(Strategy *)strategy;
- (void)contextInterface;
@end

NS_ASSUME_NONNULL_END
