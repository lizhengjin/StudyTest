//
//  ConcreteStrategyA.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "ConcreteStrategyA.h"

@implementation ConcreteStrategyA
- (void)algorithmInterface
{
    NSLog(@"ConcreteStrategyA 实现");
}
@end
