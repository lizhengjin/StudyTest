//
//  Strategy.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Strategy.h"

@implementation Strategy
- (void)algorithmInterface
{
    
}
@end
