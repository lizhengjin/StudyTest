//
//  Iterator.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "Iterator.h"

@implementation Iterator
- (id)first
{
    return nil;
}
- (id)next
{
    return nil;
}
- (BOOL)isDone
{
    return nil;
}
- (id)currentItem
{
    return nil;
}
@end
