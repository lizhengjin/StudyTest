//
//  ConcreteIterator.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "Iterator.h"

NS_ASSUME_NONNULL_BEGIN
@class ConcreteAggregate;
@interface ConcreteIterator : Iterator
- (void)concreteIterator:(ConcreteAggregate *)aggregate;
@end

NS_ASSUME_NONNULL_END
