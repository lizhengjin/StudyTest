//
//  ConcreteIterator.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "ConcreteIterator.h"
#import "ConcreteAggregate.h"
@interface ConcreteIterator ()
@property  (nonatomic, strong) ConcreteAggregate *aggregate;
@end
@implementation ConcreteIterator
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.aggregate = [[ConcreteAggregate alloc] init];
    }
    return self;
}
- (void)concreteIterator:(ConcreteAggregate *)aggregate
{
    self.aggregate = aggregate;
}
- (id)first
{
    return nil;
}
@end
