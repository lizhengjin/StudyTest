//
//  ConcreteAggregate.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "ConcreteAggregate.h"

@implementation ConcreteAggregate
- (Iterator *)createIterator
{
    return nil;
}
@end
