//
//  Iterator.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Iterator : NSObject
- (id)first;
- (id)next;
- (BOOL)isDone;
- (id)currentItem;
@end

NS_ASSUME_NONNULL_END
