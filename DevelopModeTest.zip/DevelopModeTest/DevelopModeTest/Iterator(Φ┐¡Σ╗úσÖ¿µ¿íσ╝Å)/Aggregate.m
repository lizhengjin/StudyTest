//
//  Aggregate.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "Aggregate.h"

@implementation Aggregate
- (Iterator *)createIterator
{
    return nil;
}
@end
