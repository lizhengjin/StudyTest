//
//  Receiver.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Receiver.h"

@implementation Receiver
- (void)action
{
    NSLog(@"Receive执行");
}
@end
