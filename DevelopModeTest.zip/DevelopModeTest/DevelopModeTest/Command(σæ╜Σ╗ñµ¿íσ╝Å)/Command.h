//
//  Command.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import "Receiver.h"
NS_ASSUME_NONNULL_BEGIN

@interface Command : NSObject
@property  (nonatomic, strong) Receiver *receiver;
- (void)execute;
@end

NS_ASSUME_NONNULL_END
