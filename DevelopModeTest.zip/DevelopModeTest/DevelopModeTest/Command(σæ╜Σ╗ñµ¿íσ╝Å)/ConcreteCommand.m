//
//  ConcreteCommand.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteCommand.h"

@implementation ConcreteCommand
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.receiver = [[Receiver alloc] init];
    }
    return self;
}
- (void)execute
{
    [self.receiver action];
}
@end
