//
//  Invoker.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import "Command.h"
NS_ASSUME_NONNULL_BEGIN

@interface Invoker : NSObject
@property  (nonatomic, strong) Command *command;
- (void)executeCommand;
@end

NS_ASSUME_NONNULL_END
