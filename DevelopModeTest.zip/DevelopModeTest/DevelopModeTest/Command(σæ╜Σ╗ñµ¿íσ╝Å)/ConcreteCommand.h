//
//  ConcreteCommand.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Command.h"

NS_ASSUME_NONNULL_BEGIN

@interface ConcreteCommand : Command

@end

NS_ASSUME_NONNULL_END
