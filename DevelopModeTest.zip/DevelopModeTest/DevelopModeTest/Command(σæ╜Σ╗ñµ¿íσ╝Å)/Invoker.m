//
//  Invoker.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Invoker.h"

@implementation Invoker
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.command = [[Command alloc] init];
    }
    return self;
}
- (void)setCommand:(Command *)command
{
    _command = command;
}
- (void)executeCommand
{
    [self.command execute];
}
@end
