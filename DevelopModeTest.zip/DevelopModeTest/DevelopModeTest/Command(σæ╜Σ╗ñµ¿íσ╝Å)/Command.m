//
//  Command.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Command.h"

@implementation Command
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.receiver = [[Receiver alloc] init];
    }
    return self;
}
- (void)setReceiver:(Receiver *)receiver
{
    _receiver = receiver;
}
- (void)execute
{
    
}
@end
