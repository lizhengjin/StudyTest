//
//  AdapterDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#ifndef AdapterDefine_h
#define AdapterDefine_h
#import "Target.h"
#import "Adaptee.h"
#import "Adapter.h"
#endif /* AdapterDefine_h */
