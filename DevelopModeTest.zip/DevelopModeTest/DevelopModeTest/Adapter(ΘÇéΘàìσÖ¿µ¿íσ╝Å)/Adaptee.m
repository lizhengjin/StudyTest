//
//  Adaptee.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "Adaptee.h"

@implementation Adaptee
- (void)specificRequest
{
    NSLog(@"特殊请求");
}
@end
