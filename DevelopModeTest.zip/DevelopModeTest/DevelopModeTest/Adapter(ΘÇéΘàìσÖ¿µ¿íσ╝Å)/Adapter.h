//
//  Adapter.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "Target.h"

NS_ASSUME_NONNULL_BEGIN

@interface Adapter : Target

@end

NS_ASSUME_NONNULL_END
