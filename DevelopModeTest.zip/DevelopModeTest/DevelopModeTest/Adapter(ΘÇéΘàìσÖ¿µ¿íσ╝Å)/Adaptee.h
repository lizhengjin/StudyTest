//
//  Adaptee.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Adaptee : NSObject
- (void)specificRequest;
@end

NS_ASSUME_NONNULL_END
