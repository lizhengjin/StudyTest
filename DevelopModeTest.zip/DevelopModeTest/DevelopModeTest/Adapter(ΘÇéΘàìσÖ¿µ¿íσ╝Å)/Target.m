//
//  Target.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "Target.h"

@implementation Target
- (void)request
{
    NSLog(@"普通请求");
}
@end
