//
//  StateModel.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "StateModel.h"

@implementation StateModel
- (void)handle:(ContextState *)contextState
{
    
}
@end
