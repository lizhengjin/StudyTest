//
//  StateA.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "StateA.h"

@implementation StateA
- (void)handle:(ContextState *)contextState
{
//    StateA *a = [[StateA alloc] init];
//    [contextState context_state:a];
    NSLog(@"StateA");
}
@end
