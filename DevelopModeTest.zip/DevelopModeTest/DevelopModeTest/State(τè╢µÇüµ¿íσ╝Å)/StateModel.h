//
//  StateModel.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import <Foundation/Foundation.h>
#import "ContextState.h"
NS_ASSUME_NONNULL_BEGIN
@class ContextState;
@interface StateModel : NSObject
- (void)handle:(ContextState *)contextState;
@end

NS_ASSUME_NONNULL_END
