//
//  StateDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#ifndef StateDefine_h
#define StateDefine_h

#import "StateModel.h"
#import "ContextState.h"
#import "StateA.h"
#import "StateB.h"
#endif /* StateDefine_h */
