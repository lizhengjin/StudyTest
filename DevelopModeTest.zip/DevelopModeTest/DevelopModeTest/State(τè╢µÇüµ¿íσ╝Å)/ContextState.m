//
//  ContextState.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "ContextState.h"

@implementation ContextState
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.state = [[StateModel alloc] init];
    }
    return self;
}
- (void)context_state:(StateModel *)state
{
    self.state = state;
   
}
- (void)request
{
    [self.state handle:self];
}
@end
