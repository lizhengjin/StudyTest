//
//  StateB.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import "StateB.h"

@implementation StateB
- (void)handle:(ContextState *)contextState
{
//    StateB *b = [[StateB alloc] init];
//    [contextState context_state:b];
    NSLog(@"StateB");
}
@end
