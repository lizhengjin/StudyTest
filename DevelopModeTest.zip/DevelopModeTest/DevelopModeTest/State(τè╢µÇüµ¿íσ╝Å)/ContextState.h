//
//  ContextState.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/16.
//

#import <Foundation/Foundation.h>
#import "StateModel.h"
NS_ASSUME_NONNULL_BEGIN
@class StateModel;
@interface ContextState : NSObject
@property (nonatomic, strong) StateModel *state;
- (void)context_state:(StateModel *)state;
- (void)request;
@end

NS_ASSUME_NONNULL_END
