//
//  Builder.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Builder.h"

@interface Builder  ()


@end
@implementation Builder
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.product = [[Product alloc] init];
    }
    return self;
}
- (void)buildPartA
{
   
}
- (void)buildPartB
{
    
}
- (Product *)getResult
{
    return self.product;
}
@end
