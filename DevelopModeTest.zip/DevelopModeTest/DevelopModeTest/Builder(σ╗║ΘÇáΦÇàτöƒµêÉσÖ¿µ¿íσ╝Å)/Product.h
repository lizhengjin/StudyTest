//
//  Product.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Product : NSObject
@property  (nonatomic, strong) NSMutableArray *parts;
- (void)add:(NSString *)part;
- (void)show;
@end

NS_ASSUME_NONNULL_END
