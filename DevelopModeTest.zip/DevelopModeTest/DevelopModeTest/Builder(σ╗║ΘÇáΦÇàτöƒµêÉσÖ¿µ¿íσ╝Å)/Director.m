//
//  Director.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Director.h"

@implementation Director
- (void)construct:(Builder *)builder
{
    [builder buildPartA];
    [builder buildPartB];
}
@end
