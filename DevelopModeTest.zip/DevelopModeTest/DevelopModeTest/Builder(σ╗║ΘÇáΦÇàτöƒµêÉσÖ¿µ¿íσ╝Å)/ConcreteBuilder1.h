//
//  ConcreteBuilder1.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Builder.h"

NS_ASSUME_NONNULL_BEGIN

@interface ConcreteBuilder1 : Builder

@end

NS_ASSUME_NONNULL_END
