//
//  Builder.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import <Foundation/Foundation.h>
#import "Product.h"
NS_ASSUME_NONNULL_BEGIN

@interface Builder : NSObject
@property  (nonatomic, strong) Product *product;
- (void)buildPartA;
- (void)buildPartB;
- (Product *)getResult;
@end

NS_ASSUME_NONNULL_END
