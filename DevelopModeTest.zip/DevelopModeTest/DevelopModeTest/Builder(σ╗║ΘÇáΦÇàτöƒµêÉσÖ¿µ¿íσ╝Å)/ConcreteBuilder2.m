//
//  ConcreteBuilder2.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "ConcreteBuilder2.h"

@implementation ConcreteBuilder2
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.product = [[Product alloc] init];
    }
    return self;
}
- (void)buildPartA
{
    [self.product add:@"部件c"];
}
- (void)buildPartB
{
    [self.product add:@"部件d"];
}
- (Product *)getResult
{
    return self.product;
}
@end
