//
//  ConcreteBuilder1.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "ConcreteBuilder1.h"

@implementation ConcreteBuilder1
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.product = [[Product alloc] init];
    }
    return self;
}
- (void)buildPartA
{
    [self.product add:@"部件a"];
}
- (void)buildPartB
{
    [self.product add:@"部件b"];
}
- (Product *)getResult
{
    return self.product;
}
@end
