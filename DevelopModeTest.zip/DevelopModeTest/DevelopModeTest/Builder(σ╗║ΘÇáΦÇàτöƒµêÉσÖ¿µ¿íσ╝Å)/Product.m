//
//  Product.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Product.h"

@implementation Product
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.parts = [NSMutableArray array];
    }
    return self;
}
- (void)add:(NSString *)part
{
    [self.parts addObject:part];
}
- (void)show
{
    NSLog(@"product 显示出来了");
    NSLog(@"self.parts = %@",self.parts);
    for (NSString *park in self.parts) {
        
    }
    
}
@end
