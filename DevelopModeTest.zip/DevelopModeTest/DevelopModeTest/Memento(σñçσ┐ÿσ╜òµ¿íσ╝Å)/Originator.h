//
//  Originator.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import "Memento.h"
NS_ASSUME_NONNULL_BEGIN

@interface Originator : NSObject
@property  (nonatomic, strong) NSString *state;
@property  (nonatomic, strong) Memento  *memento;
- (void)show;
@end

NS_ASSUME_NONNULL_END
