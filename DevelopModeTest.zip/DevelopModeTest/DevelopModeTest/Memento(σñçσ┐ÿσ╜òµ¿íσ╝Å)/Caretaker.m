//
//  Caretaker.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Caretaker.h"

@implementation Caretaker
- (void)setMemento:(Memento *)memento
{
    NSLog(@"memento.state = %@",memento.state);
}
@end
