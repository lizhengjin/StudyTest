//
//  Memento.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Memento.h"

@implementation Memento
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

@end
