//
//  MementoDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#ifndef MementoDefine_h
#define MementoDefine_h

#import "Originator.h"
#import "Memento.h"
#import "Caretaker.h"
#endif /* MementoDefine_h */
