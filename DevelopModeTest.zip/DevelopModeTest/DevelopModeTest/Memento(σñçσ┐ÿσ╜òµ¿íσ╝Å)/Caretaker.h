//
//  Caretaker.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import "Memento.h"
NS_ASSUME_NONNULL_BEGIN

@interface Caretaker : NSObject
@property  (nonatomic, strong) Memento *memento;
@end

NS_ASSUME_NONNULL_END
