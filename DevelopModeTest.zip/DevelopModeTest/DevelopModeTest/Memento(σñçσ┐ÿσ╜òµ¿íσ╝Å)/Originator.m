//
//  Originator.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Originator.h"

@implementation Originator
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.memento = [[Memento alloc] init];
    }
    return self;
}
- (void)setState:(NSString *)state
{
    self.memento.state = state;
}

- (void)show
{
    
}
@end
