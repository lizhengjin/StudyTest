//
//  ViewController.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "ViewController.h"
#import "ComponentDefine.h"
#import "FactoryDefine.h"
#import "StrategyDefine.h"
#import "IFactoryDefine.h"
#import "FacadeDefine.h"
#import "BuilderDefine.h"
#import "ObserverDefine.h"
#import "StateDefine.h"
#import "AdapterDefine.h"
#import "MementoDefine.h"
#import "ImplementorDefine.h"
#import "CommandDefine.h"
#import "HandlerDefine.h"
#import "MediatorDefine.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   // [self decoratorTest];
   // [self factoryTest];
  //  [self strategyTest];
  //  [self iFactoryTest];
  //  [self facadeTest];
  //  [self builderTest];
 //   [self observerTest];
 //   [self stateTest];
 //   [self adapterTest];
 //   [self mementoTest];
 //   [self implementorTest];
//    [self commandTest];
//    [self handlerTest];
      [self mediatorTest];
}
- (void)decoratorTest
{
    ConcreteComponent *c = [[ConcreteComponent alloc] init];
    ConcreteDecoratorA *d1 = [[ConcreteDecoratorA alloc] init];
    ConcreteDecoratorB *d2 = [[ConcreteDecoratorB alloc] init];
    [d1 setComponent:c];
    [d2 setComponent:d1];
    [d2 operation];
}
- (void)factoryTest
{
    Operation *ope = [OperationFactory createOperate:@"+"];
    ope.numberA = 1;
    ope.numberB = 2;
    CGFloat result = [ope getResult];
    NSLog(@"result = %f", result);
}
- (void)strategyTest
{
    Context *context = [[Context alloc] init];
//    ConcreteStrategyA *a = [[ConcreteStrategyA alloc] init];
//    [context contextStrategy:a];
    ConcreteStrategyB *b = [[ConcreteStrategyB alloc] init];
    [context contextStrategy:b];
//    ConcreteStrategyC *c = [[ConcreteStrategyC alloc] init];
//    [context contextStrategy:c];
    [context contextInterface];
    
}
- (void)iFactoryTest
{
    IFactory *factory = [[UndergraduateFactory alloc] init];
    LeiFeng *student = [factory createLeiFeng];
    [student buyRice];
    [student sweep];
    [student wash];
}
- (void)facadeTest
{
    Facade *facade = [[Facade alloc] init];
    [facade methodA];
    [facade methodB];
}
- (void)builderTest
{
    Director  *director = [[Director alloc] init];
    Builder *b1 = [[ConcreteBuilder1 alloc] init];
//    Builder *b2 = [[ConcreteBuilder2 alloc] init];
    [director construct:b1];
   // [director construct:b2];
    Product *p  = [b1 getResult];
    [p show];
}
- (void)observerTest
{
    ConcreteSubject *s = [[ConcreteSubject alloc] init];
    ConcreteObserver *ob1 = [[ConcreteObserver alloc] init];
    [ob1 concreteObserver:s name:@"111"];
    [s attach:ob1];
    ConcreteObserver  *ob2 = [[ConcreteObserver alloc] init];
    [ob2 concreteObserver:s name:@"222"];
    [s attach:ob2];
    s.subjectState = @"ascd";
    [s notify];
}
- (void)stateTest
{
    ContextState *contextState = [[ContextState alloc] init];
    StateA  *a = [[StateA alloc] init];
    [contextState context_state:a];
    [contextState request];
}
- (void)adapterTest
{
    Target *target = [[Adapter alloc] init];
    [target request];
}
- (void)mementoTest
{
    Originator *o = [[Originator alloc] init];
    o.state = @"on";
    Caretaker *c = [[Caretaker alloc] init];
    c.memento = o.memento;
    
}
- (void)implementorTest
{
    Abstraction *a = [[Abstraction alloc] init];
    a.implementor = [[ConcreteImplementorA alloc] init];
    [a operation];
    a.implementor = [[ConcreteImplementorB alloc] init];
    [a operation];
}
- (void)commandTest
{
    Receiver *r = [[Receiver alloc] init];
    Command *c = [[ConcreteCommand alloc] init];
    c.receiver = r;
    Invoker *i  = [[Invoker alloc] init];
    i.command = c;
    [i executeCommand];
}
- (void)handlerTest
{
    Handler *h1 = [[ConcreteHandler1 alloc] init];
    Handler *h2 = [[ConcreteHandler2 alloc] init];
    Handler *h3 = [[ConcreteHandler3 alloc] init];
    h1.successor = h2;
    h2.successor = h3;
    NSArray *requests = @[@2, @10, @15,@25];
    for (NSNumber *request in requests) {
        [h1 handleRequest:request.intValue];
    }
    
}
- (void)mediatorTest
{
    ConcreteMediator *m = [[ConcreteMediator alloc] init];
    ConcreteColleague1 *c1 = [[ConcreteColleague1 alloc] init];
    c1.mediator = m;
    ConcreteColleague2 *c2 = [[ConcreteColleague2 alloc] init];
    c2.mediator = m;
    m.colleague1 = c1;
    m.colleague2 = c2;
    [c1 send:@"吃了没"];
    [c2 send:@"吃完了"];
}
@end
