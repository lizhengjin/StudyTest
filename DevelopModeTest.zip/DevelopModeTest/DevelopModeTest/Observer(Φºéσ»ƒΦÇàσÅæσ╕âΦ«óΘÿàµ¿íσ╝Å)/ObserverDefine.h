//
//  ObserverDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#ifndef ObserverDefine_h
#define ObserverDefine_h

#import "Subject.h"
#import "Observer.h"
#import "ConcreteSubject.h"
#import "ConcreteObserver.h"
#endif /* ObserverDefine_h */
