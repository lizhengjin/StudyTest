//
//  ConcreteObserver.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "ConcreteObserver.h"

@implementation ConcreteObserver
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.subject = [[ConcreteSubject alloc] init];
    }
    return self;
}
- (void)concreteObserver:(ConcreteSubject *)subject name:(NSString *)name
{
    self.subject = subject;
    self.name = name;
}
- (void)update
{
    self.observerState = self.subject.subjectState;
    NSLog(@"观察者%@的状态时%@",self.name,self.observerState);
}
@end
