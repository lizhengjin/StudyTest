//
//  ConcreteSubject.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "ConcreteSubject.h"

@implementation ConcreteSubject

@end
