//
//  Subject.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Subject.h"
@interface Subject  ()
@property  (nonatomic, strong) NSMutableArray <Observer *>*observers;
@end
@implementation Subject

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.observers = [NSMutableArray array];
    }
    return self;
}
- (void)attach:(Observer *)observer
{
    [self.observers addObject:observer];
}
- (void)detach:(Observer *)observer
{
    [self.observers removeObject:observer];
}
- (void)notify
{
    for (Observer *ob in self.observers) {
        [ob update];
    }
    
}
@end
