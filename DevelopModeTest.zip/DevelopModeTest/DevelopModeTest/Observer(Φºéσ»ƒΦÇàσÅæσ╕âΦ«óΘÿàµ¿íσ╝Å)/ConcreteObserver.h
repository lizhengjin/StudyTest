//
//  ConcreteObserver.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Observer.h"
#import "ConcreteSubject.h"
NS_ASSUME_NONNULL_BEGIN

@interface ConcreteObserver : Observer
@property  (nonatomic, strong) NSString *name;
@property  (nonatomic, strong) NSString *observerState;
@property  (nonatomic, strong) ConcreteSubject  *subject;
- (void)concreteObserver:(ConcreteSubject *)subject name:(NSString *)name;
@end

NS_ASSUME_NONNULL_END
