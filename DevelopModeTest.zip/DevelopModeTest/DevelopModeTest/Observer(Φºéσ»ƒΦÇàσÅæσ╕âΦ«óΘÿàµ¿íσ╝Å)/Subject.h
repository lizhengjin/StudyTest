//
//  Subject.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import <Foundation/Foundation.h>
#import "Observer.h"
NS_ASSUME_NONNULL_BEGIN

@interface Subject : NSObject
- (void)attach:(Observer *)observer;
- (void)detach:(Observer *)observer;
- (void)notify;
@end

NS_ASSUME_NONNULL_END
