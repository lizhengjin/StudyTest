//
//  Observer.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Observer.h"

@implementation Observer
- (void)update
{
    
}
@end
