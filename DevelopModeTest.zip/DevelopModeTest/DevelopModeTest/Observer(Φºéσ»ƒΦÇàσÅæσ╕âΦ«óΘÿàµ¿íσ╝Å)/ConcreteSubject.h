//
//  ConcreteSubject.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/15.
//

#import "Subject.h"

NS_ASSUME_NONNULL_BEGIN

@interface ConcreteSubject : Subject
@property  (nonatomic, strong) NSString *subjectState;
@end

NS_ASSUME_NONNULL_END
