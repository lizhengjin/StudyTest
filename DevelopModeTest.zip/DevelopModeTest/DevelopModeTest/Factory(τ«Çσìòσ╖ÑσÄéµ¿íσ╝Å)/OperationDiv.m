//
//  OperationDiv.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "OperationDiv.h"

@implementation OperationDiv
- (CGFloat)getResult
{
    return self.numberA / self.numberB;
}
@end
