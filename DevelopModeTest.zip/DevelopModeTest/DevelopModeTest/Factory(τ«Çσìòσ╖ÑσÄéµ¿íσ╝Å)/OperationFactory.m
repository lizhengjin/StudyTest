//
//  OperationFactory.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "OperationFactory.h"
#import "OperationAdd.h"
#import "OperationSub.h"
#import "OperationMul.h"
#import "OperationDiv.h"
@implementation OperationFactory
+ (Operation *)createOperate:(NSString *)str
{
    Operation *oper = nil;
    if ([str isEqualToString:@"+"]) {
        oper = [[OperationAdd alloc] init];
    }else if ([str isEqualToString:@"-"]){
        oper = [[OperationSub alloc] init];
    }else if ([str isEqualToString:@"*"]){
        oper = [[OperationMul alloc] init];
    }else if ([str isEqualToString:@"/"]){
        oper = [[OperationDiv alloc] init];
    }
    return oper;
}
@end
