//
//  OperationAdd.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Operation.h"

NS_ASSUME_NONNULL_BEGIN

@interface OperationAdd : Operation

@end

NS_ASSUME_NONNULL_END
