//
//  Operation.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Operation.h"

@implementation Operation
- (CGFloat)getResult
{
    return 0;
}
@end
