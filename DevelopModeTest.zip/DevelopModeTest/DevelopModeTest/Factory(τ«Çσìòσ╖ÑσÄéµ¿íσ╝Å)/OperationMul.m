//
//  OperationMul.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "OperationMul.h"

@implementation OperationMul
- (CGFloat)getResult
{
    return self.numberA * self.numberB;
}
@end
