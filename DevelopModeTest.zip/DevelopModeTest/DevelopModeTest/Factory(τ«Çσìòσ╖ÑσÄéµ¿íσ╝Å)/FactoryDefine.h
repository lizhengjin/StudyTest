//
//  FactoryDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#ifndef FactoryDefine_h
#define FactoryDefine_h
#import "Operation.h"
#import "OperationAdd.h"
#import "OperationSub.h"
#import "OperationMul.h"
#import "OperationDiv.h"
#import "OperationFactory.h"
#endif /* FactoryDefine_h */
