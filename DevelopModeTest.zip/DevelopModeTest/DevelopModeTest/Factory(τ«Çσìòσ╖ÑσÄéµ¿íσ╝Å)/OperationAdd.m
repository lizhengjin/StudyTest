//
//  OperationAdd.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "OperationAdd.h"

@implementation OperationAdd
- (CGFloat)getResult
{
    return self.numberA + self.numberB;
}
@end
