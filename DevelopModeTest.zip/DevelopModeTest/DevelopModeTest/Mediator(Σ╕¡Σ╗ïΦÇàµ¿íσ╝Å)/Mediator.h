//
//  Mediator.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import "Colleague.h"
NS_ASSUME_NONNULL_BEGIN
@class Colleague;
@interface Mediator : NSObject
- (void)sendMessage:(NSString *)message colleague:(Colleague *)colleague;
@end

NS_ASSUME_NONNULL_END
