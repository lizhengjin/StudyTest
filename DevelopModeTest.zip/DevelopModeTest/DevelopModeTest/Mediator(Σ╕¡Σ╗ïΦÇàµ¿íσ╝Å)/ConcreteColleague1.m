//
//  ConcreteColleague1.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteColleague1.h"

@implementation ConcreteColleague1

- (void)send:(NSString *)message
{
    [self.mediator sendMessage:message colleague:self];
}
- (void)notify:(NSString *)message
{
    NSLog(@"ConcreteColleague1通知");
}
@end
