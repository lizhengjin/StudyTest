//
//  ConcreteMediator.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteMediator.h"

@implementation ConcreteMediator
- (void)setColleague1:(ConcreteColleague1 *)colleague1
{
    _colleague1 = colleague1;
}
- (void)setColleague2:(ConcreteColleague2 *)colleague2
{
    _colleague2 = colleague2;
}

- (void)sendMessage:(NSString *)message colleague:(Colleague *)colleague
{
    if (colleague == self.colleague1) {
        [self.colleague2 notify:message];
    }else{
        [self.colleague1 notify:message];
    }
}
@end
