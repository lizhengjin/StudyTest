//
//  Mediator.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Mediator.h"

@implementation Mediator
- (void)sendMessage:(NSString *)message colleague:(Colleague *)colleague
{
    
}
@end
