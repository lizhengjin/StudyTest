//
//  Colleague.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Colleague.h"

@implementation Colleague
- (void)setMediator:(Mediator *)mediator
{
    _mediator = mediator;
}
- (void)send
{
    
}
- (void)notify:(NSString *)message
{
    
}
@end
