//
//  Colleague.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import <Foundation/Foundation.h>
#import "Mediator.h"
NS_ASSUME_NONNULL_BEGIN
@class Mediator;
@interface Colleague : NSObject
@property  (nonatomic, strong) Mediator *mediator;
- (void)send:(NSString *)message;
- (void)notify:(NSString *)message;
@end

NS_ASSUME_NONNULL_END
