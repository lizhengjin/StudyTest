//
//  ConcreteColleague1.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Colleague.h"

NS_ASSUME_NONNULL_BEGIN

@interface ConcreteColleague1 : Colleague

@end

NS_ASSUME_NONNULL_END
