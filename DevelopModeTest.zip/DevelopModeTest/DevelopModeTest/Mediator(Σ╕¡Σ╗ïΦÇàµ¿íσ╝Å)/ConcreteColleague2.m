//
//  ConcreteColleague2.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteColleague2.h"

@implementation ConcreteColleague2

- (void)send:(NSString *)message
{
    [self.mediator sendMessage:message colleague:self];
}
- (void)notify:(NSString *)message
{
    NSLog(@"ConcreteColleague2通知");
}
@end
