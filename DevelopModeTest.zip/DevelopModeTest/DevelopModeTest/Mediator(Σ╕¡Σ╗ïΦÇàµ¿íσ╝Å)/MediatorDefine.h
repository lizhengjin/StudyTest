//
//  MediatorDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#ifndef MediatorDefine_h
#define MediatorDefine_h

#import "Mediator.h"
#import "Colleague.h"
#import "ConcreteMediator.h"
#import "ConcreteColleague1.h"
#import "ConcreteColleague2.h"
#endif /* MediatorDefine_h */
