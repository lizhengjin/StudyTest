//
//  ConcreteImplementorB.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteImplementorB.h"

@implementation ConcreteImplementorB
- (void)operation
{
    NSLog(@"ConcreteImplementorB");
}
@end
