//
//  RefinedAbstraction.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Abstraction.h"

NS_ASSUME_NONNULL_BEGIN

@interface RefinedAbstraction : Abstraction

@end

NS_ASSUME_NONNULL_END
