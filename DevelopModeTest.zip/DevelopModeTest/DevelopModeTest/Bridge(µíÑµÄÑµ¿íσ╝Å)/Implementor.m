//
//  Implementor.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Implementor.h"

@implementation Implementor
- (void)operation
{
    
}
@end
