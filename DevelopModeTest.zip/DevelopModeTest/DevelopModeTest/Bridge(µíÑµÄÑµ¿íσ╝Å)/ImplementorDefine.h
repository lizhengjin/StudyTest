//
//  ImplementorDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#ifndef ImplementorDefine_h
#define ImplementorDefine_h

#import "Implementor.h"
#import "ConcreteImplementorA.h"
#import "ConcreteImplementorB.h"
#import "Abstraction.h"
#import "RefinedAbstraction.h"
#endif /* ImplementorDefine_h */
