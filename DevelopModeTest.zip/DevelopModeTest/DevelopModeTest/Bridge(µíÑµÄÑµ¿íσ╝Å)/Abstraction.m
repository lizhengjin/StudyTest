//
//  Abstraction.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Abstraction.h"

@implementation Abstraction
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.implementor = [[Implementor alloc] init];
    }
    return self;
}
- (void)operation
{
    [self.implementor operation];
}
@end
