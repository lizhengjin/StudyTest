//
//  ConcreteImplementorA.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteImplementorA.h"

@implementation ConcreteImplementorA
- (void)operation
{
    NSLog(@"ConcreteImplementorA");
}
@end
