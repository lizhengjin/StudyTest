//
//  HandlerDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#ifndef HandlerDefine_h
#define HandlerDefine_h

#import "Handler.h"
#import "ConcreteHandler1.h"
#import "ConcreteHandler2.h"
#import "ConcreteHandler3.h"
#endif /* HandlerDefine_h */
