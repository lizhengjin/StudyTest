//
//  ConcreteHandler3.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteHandler3.h"

@implementation ConcreteHandler3
- (void)handleRequest:(int)request
{
    if (request >= 20 && request < 30) {
        NSLog(@"ConcreteHandler3处理");
    }
    else if (self.successor != nil) {
        [self.successor handleRequest:request];
    }
}
@end
