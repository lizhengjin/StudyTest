//
//  ConcreteHandler1.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Handler.h"

NS_ASSUME_NONNULL_BEGIN

@interface ConcreteHandler1 : Handler

@end

NS_ASSUME_NONNULL_END
