//
//  Handler.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "Handler.h"

@implementation Handler
- (void)setSuccessor:(Handler *)successor
{
    _successor = successor;
}
- (void)handleRequest:(int)request
{
    
}
@end
