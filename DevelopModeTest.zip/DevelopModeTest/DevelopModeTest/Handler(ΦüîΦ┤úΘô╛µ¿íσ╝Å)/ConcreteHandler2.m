//
//  ConcreteHandler2.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteHandler2.h"

@implementation ConcreteHandler2
- (void)handleRequest:(int)request
{
    if (request >= 10 && request < 20) {
        NSLog(@"ConcreteHandler2处理");
    }
    else if (self.successor != nil) {
        [self.successor handleRequest:request];
    }
}
@end
