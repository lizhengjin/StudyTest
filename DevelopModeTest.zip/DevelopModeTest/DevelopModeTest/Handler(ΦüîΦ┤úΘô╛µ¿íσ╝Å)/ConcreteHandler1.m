//
//  ConcreteHandler1.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/19.
//

#import "ConcreteHandler1.h"

@implementation ConcreteHandler1
- (void)handleRequest:(int)request
{
    if (request >= 0 && request < 10) {
        NSLog(@"ConcreteHandler1处理");
    }
    else if (self.successor != nil) {
        [self.successor handleRequest:request];
    }
}
@end
