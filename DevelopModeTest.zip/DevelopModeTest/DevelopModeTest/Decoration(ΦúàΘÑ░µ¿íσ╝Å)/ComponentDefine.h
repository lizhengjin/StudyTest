//
//  ComponentDefine.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#ifndef ComponentDefine_h
#define ComponentDefine_h

#import "Component.h"
#import "ConcreteComponent.h"
#import "Decorator.h"
#import "ConcreteDecoratorA.h"
#import "ConcreteDecoratorB.h"
#endif /* ComponentDefine_h */
