//
//  Decorator.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Decorator.h"

@implementation Decorator

- (void)setComponent:(Component *)component
{
    _component = component;
}
- (void)operation
{  // 重写operation ,实际执行的是[self.component operation]
    [self.component operation];
    NSLog(@"Decorator装饰行为");
}
@end
