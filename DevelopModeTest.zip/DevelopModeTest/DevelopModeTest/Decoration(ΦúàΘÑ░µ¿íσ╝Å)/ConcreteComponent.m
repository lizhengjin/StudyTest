//
//  ConcreteComponent.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "ConcreteComponent.h"

@implementation ConcreteComponent
- (void)operation
{
    NSLog(@"ConcreteComponent  operation");
}
@end
