//
//  Component.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Component.h"

@implementation Component
- (void)operation
{
    
}
@end
