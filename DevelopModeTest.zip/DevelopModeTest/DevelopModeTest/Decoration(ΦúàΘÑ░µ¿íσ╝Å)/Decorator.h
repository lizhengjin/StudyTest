//
//  Decorator.h
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "Component.h"

NS_ASSUME_NONNULL_BEGIN

@interface Decorator : Component
@property  (nonatomic, strong) Component *component;
//- (void)setComponent:(Component * _Nonnull)component;
@end

NS_ASSUME_NONNULL_END
