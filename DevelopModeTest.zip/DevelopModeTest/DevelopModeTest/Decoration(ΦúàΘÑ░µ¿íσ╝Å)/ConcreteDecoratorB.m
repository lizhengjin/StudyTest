//
//  ConcreteDecoratorB.m
//  DevelopModeTest
//
//  Created by liqi on 2020/10/13.
//

#import "ConcreteDecoratorB.h"

@implementation ConcreteDecoratorB
- (void)operation
{
    [super operation];
    [self addStateB];
}
- (void)addStateB
{
    NSLog(@"ConcreteDecoratorB装饰行为");
}
@end
