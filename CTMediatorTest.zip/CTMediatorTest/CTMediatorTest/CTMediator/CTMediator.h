//
//  CTMediator.h
//  CTMediatorTest
//
//  Created by liqi on 2019/5/21.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

extern  NSString * const kCTMediatorParamsKeySwiftTargetModuleName;
@interface CTMediator : NSObject

+ (instancetype)sharedInstance;
// 远程调用app入口
- (id)performActionWithUrl:(NSURL *)url completion:(void(^)(NSDictionary *info))completion;
//本地app调用组件
- (id)performTarget:(NSString *)targetName action:(NSString *)actionName params:(NSDictionary *)params shouldCacheTarget:(BOOL)shouldCacheTarget;
//释放掉某个targetName的缓存
- (void)releaseCachedTargetWithTargetName:(NSString *)targetName;

@end

NS_ASSUME_NONNULL_END












