//
//  Target_First.m
//  CTMediatorTest
//
//  Created by liqi on 2019/5/21.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "Target_First.h"
#import "FirstViewController.h"
@implementation Target_First
- (UIViewController *)Action_Category_ViewController:(NSDictionary *)params
{
    typedef void (^CallbackType)(NSString *);
    CallbackType callback = params[@"callback"];
    if (callback) {
        callback(@"first success");
    }
    FirstViewController *first = [[FirstViewController alloc] init];
    return first;
}
@end
