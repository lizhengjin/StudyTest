//
//  CTMediator+Second.m
//  CTMediatorTest
//
//  Created by liqi on 2019/5/21.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "CTMediator+Second.h"

@implementation CTMediator (Second)

- (UIViewController *)Second_viewControllerWithContentText:(NSString *)contentText
{
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    params[@"contextText"] = contentText;
    return [self performTarget:@"Second" action:@"viewController" params:params shouldCacheTarget:NO];
}
@end
