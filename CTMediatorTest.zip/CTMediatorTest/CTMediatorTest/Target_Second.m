//
//  Target_Second.m
//  CTMediatorTest
//
//  Created by liqi on 2019/5/21.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "Target_Second.h"
#import "SecondViewController.h"
@implementation Target_Second
- (UIViewController *)Action_viewController:(NSDictionary *)params
{
    NSString *contentText = params[@"contentText"];
    SecondViewController *second = [[SecondViewController alloc] initWithContentText:contentText];
    return second;
}
@end
