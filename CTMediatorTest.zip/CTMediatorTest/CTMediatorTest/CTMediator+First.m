//
//  CTMediator+First.m
//  CTMediatorTest
//
//  Created by liqi on 2019/5/21.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "CTMediator+First.h"

@implementation CTMediator (First)
- (UIViewController *)First_Category_Objc_ViewControllerWithCallback:(void (^)(NSString * _Nonnull))callback
{
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    params[@"callback"] = callback;
    return [self performTarget:@"First" action:@"Category_ViewController" params:params shouldCacheTarget:NO];
}
@end
