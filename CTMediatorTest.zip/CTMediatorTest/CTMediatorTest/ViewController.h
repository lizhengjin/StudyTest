//
//  ViewController.h
//  CTMediatorTest
//
//  Created by liqi on 2019/5/21.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

