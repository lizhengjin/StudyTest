//
//  ShopModule.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "ShopModule.h"
#import "BeeHive.h"
BeeHiveMod(ShopModule)

@interface ShopModule()<BHModuleProtocol>

@end
@implementation ShopModule

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSLog(@"shop module init");
    }
    return self;
}

- (NSInteger)moduleLevel
{
    return 0;
}

- (void)modSetUp:(BHContext *)context
{
    NSLog(@"shopModule setup ...");
}

@end











