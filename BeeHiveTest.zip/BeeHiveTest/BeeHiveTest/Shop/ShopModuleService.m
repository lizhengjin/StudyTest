//
//  ShopModuleService.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "ShopModuleService.h"

@implementation ShopModuleService

@end
