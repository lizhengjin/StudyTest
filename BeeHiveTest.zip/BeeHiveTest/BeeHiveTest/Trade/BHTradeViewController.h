//
//  BHTradeViewController.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BHService.h"
NS_ASSUME_NONNULL_BEGIN

@interface BHTradeViewController : UIViewController<TradeServiceProtocol>

@end

NS_ASSUME_NONNULL_END
