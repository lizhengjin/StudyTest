//
//  TradeModule.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "TradeModule.h"
#import "BeeHive.h"
#import "BHTradeViewController.h"
@interface TradeModule()<BHModuleProtocol>

@end

@implementation TradeModule
BeeHiveMod(TradeModule)
//+ (void)load
//{
//    [BeeHive registerDynamicModule:[self class]];
//}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSLog(@"TradeModule init ----1111");
    }
    return self;
}

- (void)modInit:(BHContext *)context
{
    NSLog(@"TradeModule  modInit -----2222");
    
    id<TradeServiceProtocol>  service = [[BeeHive shareInstance] createService:@protocol(TradeServiceProtocol)];
    service.itemId = @"TradeModule就这样结束吧";
}

- (void)modSetUp:(BHContext *)context
{
    [[BeeHive shareInstance] registerService:@protocol(TradeServiceProtocol) service:[BHTradeViewController class]];
    NSLog(@"TradeModule setup212323");
}

@end












