//
//  ViewController.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
