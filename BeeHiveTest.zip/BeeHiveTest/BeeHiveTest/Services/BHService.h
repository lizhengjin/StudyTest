//
//  BHService.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#ifndef BHService_h
#define BHService_h

#import "HomeServiceProtocol.h"
#import "TradeServiceProtocol.h"
#import "UserTrackServiceProtocol.h"
#import "AppUISkeletonServiceProtocol.h"
#import "AppConfigServiceProtocol.h"

#endif /* BHService_h */
