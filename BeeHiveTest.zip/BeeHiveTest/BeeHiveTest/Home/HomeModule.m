//
//  HomeModule.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "HomeModule.h"
#import "BeeHive.h"
#import "BHService.h"
#import "BHViewController.h"

@interface HomeModule()<BHModuleProtocol>

@end

@implementation HomeModule

- (void)modInit:(BHContext *)context
{
     NSLog(@"HomeModule init...;");
    switch (context.env) {
        case BHEnvironmentDev:
            
            break;
        case BHEnvironmentProd:
            
            break;
        default:
            break;
    }
}

- (void)modSetUp:(BHContext *)context
{
    NSLog(@"HomeModule setup;");
}

@end
