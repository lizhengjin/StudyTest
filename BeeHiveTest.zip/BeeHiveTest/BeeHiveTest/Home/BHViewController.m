//
//  BHViewController.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "BHViewController.h"

#import "BeeHive.h"
#import "BHService.h"

BeeHiveService(HomeServiceProtocol,BHViewController)
@interface BHViewController ()<HomeServiceProtocol>

@property (nonatomic, strong) NSMutableArray *registerViewControllers;

@end

@interface demoTableViewController : UIViewController

@end

@implementation BHViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.registerViewControllers = [[NSMutableArray alloc] initWithCapacity:1];
        
        demoTableViewController *v1 = [[demoTableViewController alloc] init];
        if ([v1 isKindOfClass:[UIViewController class]]) {
            [self registerViewController:(UIViewController *)v1 title:@"首页" iconName:@"tabbaritem_home" selectIconName:@"tabbaritem_home_select"];
        }
        
        id<UserTrackServiceProtocol> v4 = [[BeeHive shareInstance] createService:@protocol(UserTrackServiceProtocol)];
        if ([v4 isKindOfClass:[UIViewController class]]) {
            [self registerViewController:(UIViewController *)v4 title:@"找车位" iconName:@"tabbaritem_find" selectIconName:@"tabbaritem_find_select"];
        }
        
        id<TradeServiceProtocol> v2 = [[BeeHive shareInstance] createService:@protocol(TradeServiceProtocol)];
        if ([v2 isKindOfClass:[UIViewController class]]) {
            v2.itemId = @"就是一个标记号";
            [self registerViewController:(UIViewController *)v2 title:@"我的" iconName:@"tabbaritem_me" selectIconName:@"tabbaritem_me_select"];
        }
        
//        id<TradeServiceProtocol> s2 = [[BeeHive shareInstance] createService:@protocol(TradeServiceProtocol)];
//        if ([s2 isKindOfClass:[UIViewController class]]) {
//            s2.itemId= @"随便显示了";
//            [self registerViewController:(UIViewController *)s2 title:@"j又一个假的" iconName:nil];
//        }
    }
    return self;
}
-(void)registerViewController:(UIViewController *)vc title:(NSString *)title iconName:(NSString *)iconName  selectIconName:(NSString *)selectIconName
{
    vc.tabBarItem.image = [UIImage imageNamed: iconName];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectIconName];
    vc.tabBarItem.title = title;
    
    [self.registerViewControllers addObject:vc];
    
    self.viewControllers = self.registerViewControllers;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
}



@end


@implementation demoTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}

@end
