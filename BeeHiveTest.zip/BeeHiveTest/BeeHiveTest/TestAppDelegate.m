//
//  TestAppDelegate.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "TestAppDelegate.h"
#import "BeeHive.h"
#import "BHService.h"
#import "BHTimerProfiler.h"
@implementation TestAppDelegate

@synthesize window;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [BHContext shareInstance].application = application;
    [BHContext shareInstance].launchOptions = launchOptions;
    [BHContext shareInstance].moduleConfigName = @"BeeHive.bundle/BeeHive";
    [BHContext shareInstance].serviceConfigName = @"BeeHive.bundle/BHService";
    
    [BeeHive shareInstance].enableException = YES;
    [[BeeHive shareInstance] setContext:[BHContext shareInstance]];
    [[BHTimerProfiler sharedTimeProfiler] recordEventTime:@"BeeHive: supre start launch"];
    
    [super application:application didFinishLaunchingWithOptions:launchOptions];
    
    id<HomeServiceProtocol> homeVc = [[BeeHive shareInstance] createService:@protocol(HomeServiceProtocol)];
    
    if ([homeVc isKindOfClass:[UIViewController class]]) {
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:(UIViewController *)homeVc];
        
        self.window  = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        self.window.rootViewController = nav;
        
        [self.window makeKeyAndVisible];
    }
    
    
    return YES;
}


@end
















