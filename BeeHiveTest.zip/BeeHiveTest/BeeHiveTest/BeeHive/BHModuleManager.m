//
//  BHModuleManager.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "BHModuleManager.h"
#import "BHModuleProtocol.h"
#import "BHContext.h"
#import "BHTimerProfiler.h"
#import "BHAnnotation.h"

#define kModuleArrayKey @"noduleClasses"
#define kModileInfoNameKey @"moduleClass"
#define kModuleInfoLevelKey @"moduleLevel"

static NSString *kSetupSelector  = @"modSetUp:";
static NSString *kInitSelector   = @"modInit:";
static NSString *kSplashSelector = @"modSplash:";
static NSString *kTearDownSelector = @"modTearDown:";
static NSString *kWillResignActiveSelector = @"modWillResignActive";
static NSString *kDidEnterBackgroundSelector = @"modDidEnterBackground:";
static NSString *kWillEnterForegroundSelector = @"modWillEnterForeground:";
static NSString *kDidBecomeActiveSelector = @"modDidBecomeActive:";
static NSString *kWillTerminateSelector  = @"modWillTerminate:";
static NSString *kUnmountEventSelector  = @"modUnmount:";
static NSString *kQuickActionSelector  = @"modQuickAction:";
static NSString *kOpenURLSelector   = @"modOpenURL:";
static NSString *kDidReceiveMemoryWarningSelector = @"modDidReceiveMemoryWaring:";
static NSString *kFailToRegisterForRemoteNotificationsSelector = @"modDidFailToRegisterForRemoteNotifications:";
static NSString *kDidRegisterForRemoteNotificationsSelector = @"modDidRegisterForRemoteNotifications:";
static NSString *kDidReceiveRemoteNotificationsSelector  = @"modDidReceiveRemoteNotification:";
static NSString *kDidReceiveLocalNotificationsSelector   = @"modDidReceiveLocalNotification:";
static NSString *kWillContinueUserActivitySelector       = @"modWillContinueUserActivity:";
static NSString *kContinueUserActivitySelector           = @"modContinueUserActivity:";
static NSString *kDidUpdateContinueUserActivitySelector  = @"modDidUodateContinueUserActivity:";
static NSString *kFailToContinueUserActivitySelector     = @"modDidFailToContinueUserActivity:";
static NSString *kAppCustomSelector    = @"modDidCustomEvent:";
@interface BHModuleManager()

@property (nonatomic, strong) NSMutableArray  *BHModuleDynamicClasses;

@property (nonatomic, strong) NSMutableArray  *BHModules;

@end


@implementation BHModuleManager
#pragma mark - public

+ (instancetype)sharedManager
{
    static id sharedManager = nil;
    static dispatch_once_t onceToken = 0;
    dispatch_once(&onceToken, ^{
        sharedManager = [[BHModuleManager alloc] init];
    });
    return sharedManager;
}

- (void)loadLocalModules
{
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:[BHContext shareInstance].moduleConfigName ofType:@"plist"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:plistPath]) {
        return;
    }
    
    NSDictionary *moduleList = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
    
    NSArray *modulesArray = [moduleList objectForKey:kModuleArrayKey];
    
    [self.BHModules addObjectsFromArray:modulesArray];
}
- (void)registerDynamicModule:(Class)moduleClass
{
    [self addModuleFromObject:moduleClass];
}

-(void)registedAllModules
{
    [self.BHModules sortUsingComparator:^NSComparisonResult(NSDictionary *module1, NSDictionary *module2) {
        NSNumber *module1Level = (NSNumber *)[module1 objectForKey:kModuleInfoLevelKey];
        NSNumber *module2Levle = (NSNumber *)[module2 objectForKey:kModuleInfoLevelKey];
        
        return [module1Level intValue] > [module2Levle intValue];
    }];
    
    NSMutableArray *tmpArray = [NSMutableArray array];
    
    [self.BHModules enumerateObjectsUsingBlock:^(NSDictionary *module, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *classStr = [module objectForKey:kModileInfoNameKey];
        Class moduleClass = NSClassFromString(classStr);
        if (NSStringFromClass(moduleClass)) {
            id<BHModuleProtocol> moduleInstance = [[moduleClass alloc] init];
            [tmpArray addObject:moduleInstance];
        }
    }];
    
    [self.BHModules removeAllObjects];
    [self.BHModules addObjectsFromArray:tmpArray];
}

- (void)registedAnnotationModules
{
    
    NSArray<NSString *>*mods = [BHAnnotation AnnotationModules];
    for (NSString *modName in mods) {
        Class cls;
        if (modName) {
            cls = NSClassFromString(modName);
            
            if (cls) {
                [self registerDynamicModule:cls];
            }
        }
    }
}

- (void)triggerEvent:(BHModuleEventType)eventType
{
    switch (eventType) {
        case BHMSetUpEvent:
            [self handleModuleEvent:kSetupSelector];
            break;
        case BHMInitEvent:
            [self handleModulesInitEvent];
            break;
        case BHMTearDownEvent:
            [self handleModulesTearDownEvent];
            break;
        case BHMSplashEvent:
            [self handleModuleEvent:kSplashSelector];
            break;
        case BHMWillResignActiveEvent:// app正在使用,来电,锁屏是挂起状态
            [self handleModuleEvent:kWillResignActiveSelector];
            break;
        case BHMDidEnterBackgroundEvent: //已经进入后台
            [self handleModuleEvent:kDidEnterBackgroundSelector];
            break;
        case BHMWillEnterBackgroundEvent: //将要进入后台
            [self handleModuleEvent:kWillEnterForegroundSelector];
            break;
        case BHMDidBecomeActiveEvent: //app重新回到前台
            [self handleModuleEvent:kDidBecomeActiveSelector];
            break;
        case BHMWillTerminateEvent: //app将被杀死
            [self handleModuleEvent:kWillTerminateSelector];
            break;
        case BHMUnmountEvent:
            [self handleModuleEvent:kUnmountEventSelector];
            break;
         case BHMOpenURLEvent:
            [self handleModuleEvent:kOpenURLSelector];
            break;
         case BHMDidReceiveMemoryWarningEvent:
            [self handleModuleEvent:kDidReceiveMemoryWarningSelector];
            break;
         case BHMDidReceiveRemoteNotificationEvent:
            [self handleModuleEvent:kDidReceiveRemoteNotificationsSelector];
            break;
         case BHMDidFailToRegisterForRemoteNotificationsEvent:
            [self handleModuleEvent:kFailToRegisterForRemoteNotificationsSelector];
            break;
          case BHMDidRegisterForRemoteNotificationsEvent:
            [self handleModuleEvent:kDidRegisterForRemoteNotificationsSelector];
            break;
          case BHMDidReceiveLocalNotificationEvent:
            [self handleModuleEvent:kDidReceiveLocalNotificationsSelector];
            break;
          case BHMWillContinueUserActivityEvent:
            [self handleModuleEvent:kWillContinueUserActivitySelector];
            break;
          case BHMContinueUserActivityEvent:
            [self handleModuleEvent:kContinueUserActivitySelector];
            break;
          case BHMDidFailToContinueUserActivityEvent:
            [self handleModuleEvent:kFailToContinueUserActivitySelector];
            break;
          case BHMDidUpdateUserActivityEvent:
            [self handleModuleEvent:kDidUpdateContinueUserActivitySelector];
            break;
           case BHMQuickActionEvent:
            [self handleModuleEvent:kQuickActionSelector];
            break;

        default:
            [BHContext shareInstance].customEvent = eventType;
            [self handleModuleEvent:kAppCustomSelector];
            break;
    }
}


#pragma mark - life loop

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.BHModuleDynamicClasses = [NSMutableArray array];
    }
    return self;
}

#pragma mark - private

- (BHModuleLevel)checkModuleLevel:(NSInteger)level
{
    switch (level) {
        case 0:
            return BHModuleBasic;
            break;
        case 1:
            return BHModuleNormal;
            break;
        default:
            break;
    }
    return BHModuleNormal;
}

- (void)addModuleFromObject:(id)object
{
    Class class;
    NSString *moduleName = nil;
    
    if (object) {
        class = object;
        moduleName = NSStringFromClass(class);
    }else{
        return;
    }
    
    if ([class conformsToProtocol:@protocol(BHModuleProtocol)]) {
        NSMutableDictionary *moduleInfo = [NSMutableDictionary dictionary];
        
        BOOL responseBasicLevel = [class instancesRespondToSelector:@selector(basicModuleLevel)];
        int levelInt = 1;
        if (responseBasicLevel) {
            levelInt = 0;
        }
        
        [moduleInfo setObject:@(levelInt) forKey:kModuleInfoLevelKey];
        if (moduleName) {
            [moduleInfo setObject:moduleName forKey:kModileInfoNameKey];
        }
        
        [self.BHModules addObject:moduleInfo];
    }
}

#pragma mark - property setter or getter

- (NSMutableArray *)BHModules
{
    if (!_BHModules) {
        _BHModules = [NSMutableArray array];
    }
    return _BHModules;
}

#pragma mark - module protocol

- (void)handleModulesInitEvent
{
    [self.BHModules enumerateObjectsUsingBlock:^(id <BHModuleProtocol> moduleInstance, NSUInteger idx, BOOL * _Nonnull stop) {
        __weak typeof(&*self) wself = self;
        void ( ^ bk )(void);
        bk = ^{
            __strong typeof(&*self) sself = wself;
            if (sself) {
                if ([moduleInstance respondsToSelector:@selector(modInit:)]) {
                    [moduleInstance modInit:[BHContext shareInstance]];
                }
            }
        };
        [[BHTimerProfiler sharedTimeProfiler] recordEventTime:[NSString stringWithFormat:@"%@ --- modInit:",[moduleInstance class]]];
        
        if ([moduleInstance respondsToSelector:@selector(async)]) {
            BOOL async = [moduleInstance async];
            if (async) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    bk();
                });
            } else {
                bk();
            }
        }else {
            bk();
        }
        
    }];
    
    
}

- (void)handleModulesTearDownEvent
{
    for (int i = (int)self.BHModules.count -1; i >= 0 ; i--) {
        id<BHModuleProtocol> moduleInstance = [self.BHModules objectAtIndex:i];
        if (moduleInstance && [moduleInstance respondsToSelector:@selector(modTearDown:)]) {
            [moduleInstance modTearDown:[BHContext shareInstance]];
        }
    }
}

- (void)handleModuleEvent:(NSString *)selectorStr
{
    SEL seletor = NSSelectorFromString(selectorStr);
    [self.BHModules enumerateObjectsUsingBlock:^(id<BHModuleProtocol> moduleInstance, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([moduleInstance respondsToSelector:seletor]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
            [moduleInstance performSelector:seletor withObject:[BHContext shareInstance]];
#pragma mark diagnostic pop
            
            [[BHTimerProfiler sharedTimeProfiler] recordEventTime:[NSString stringWithFormat:@"%@ --- %@",[moduleInstance class],NSStringFromSelector(seletor)]];
        }
    }];
}

@end





















