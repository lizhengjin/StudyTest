//
//  BeeHive.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BHModuleProtocol.h"
#import "BHContext.h"
#import "BHAppDelegate.h"
#import "BHModuleManager.h"
#import "BHServiceManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface BeeHive : NSObject

@property (nonatomic, strong) BHContext *context;
@property (nonatomic, assign) BOOL enableException;
+ (instancetype)shareInstance;

+ (void)registerDynamicModule:(Class)moduleClass;
- (id)createService:(Protocol *)proto;
- (void)registerService:(Protocol *)proto service:(Class)serviceClass;
+ (void)triggerCustomEvent:(NSInteger)eventType;


@end

NS_ASSUME_NONNULL_END
















