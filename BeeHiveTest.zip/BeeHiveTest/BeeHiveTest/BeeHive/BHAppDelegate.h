//
//  BHAppDelegate.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface BHAppDelegate : UIResponder <UIApplicationDelegate>

@end
typedef void (^notificationResultHandler)(UIBackgroundFetchResult);

@interface BHNotificationsItem : NSObject

@property (nonatomic, strong) NSError *notificationError;
@property (nonatomic, strong) NSData  *deviceToken;
@property (nonatomic, strong) NSDictionary *userInfo;
@property (nonatomic, assign) notificationResultHandler notificationResultHander;
@property (nonatomic, strong) UILocalNotification  *localNotification;

@end

@interface BHOpenURLItem : NSObject

@property (nonatomic, strong) NSURL *openURL;
@property (nonatomic, strong) NSString *sourceApplication;
@property (nonatomic, strong) NSDictionary *options;

@end

typedef void (^shortcutItemCompletionHandler)(BOOL);

@interface BHShortcutItem : NSObject

#if __IPHONE_OS_VERSION_MAX_ALLOWED > 80400
@property (nonatomic, strong) UIApplicationShortcutItem *shortcurItem;
@property (nonatomic, copy) shortcutItemCompletionHandler scompletionHandler;
#endif

@end

typedef void (^restorationHandler)(NSArray *);

@interface BHUserActivityItem : NSObject

@property (nonatomic, strong) NSString *userActivityType;
@property (nonatomic, strong) NSUserActivity *userActivity;
@property (nonatomic, strong) NSError *userActivityError;
@property (nonatomic, strong) restorationHandler restorationHandler;

@end


NS_ASSUME_NONNULL_END
















