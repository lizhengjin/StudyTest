//
//  BHConfig.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BHConfig : NSObject

+ (instancetype)shareInstance;

+ (id)get:(NSString *)key;

+ (BOOL)has:(NSString *)key;
+ (void)add:(NSDictionary *)parameters;
+ (NSMutableDictionary *)getAll;
+ (NSString *)stringValue:(NSString *)key;
+ (NSDictionary *)dictionaryValue:(NSString *)key;
+ (NSInteger)integerValue:(NSString *)key;

+ (float)floatValue:(NSString *)key;
+ (BOOL)boolValue:(NSString *)key;
+ (NSArray *)arrayValue:(NSString *)key;
+ (void)set:(NSString *)key value:(id)value;
+ (void)set:(NSString *)key boolValue:(BOOL)value;
+ (void)set:(NSString *)key integerValue:(NSInteger)value;
+ (void)clear;
@end

NS_ASSUME_NONNULL_END























