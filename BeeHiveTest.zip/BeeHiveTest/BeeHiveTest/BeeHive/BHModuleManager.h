//
//  BHModuleManager.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, BHModuleLevel)
{
  BHModuleBasic =0,
  BHModuleNormal = 1,
};

typedef NS_ENUM(NSInteger, BHModuleEventType)
{
    BHMSetUpEvent =0,
    BHMInitEvent,
    BHMTearDownEvent,
    BHMSplashEvent,
    BHMQuickActionEvent,
    BHMWillResignActiveEvent,
    BHMDidEnterBackgroundEvent,
    BHMWillEnterBackgroundEvent,
    BHMDidBecomeActiveEvent,
    BHMWillTerminateEvent,
    BHMUnmountEvent,
    BHMOpenURLEvent,
    BHMDidReceiveMemoryWarningEvent,
    BHMDidFailToRegisterForRemoteNotificationsEvent,
    BHMDidRegisterForRemoteNotificationsEvent,
    BHMDidReceiveRemoteNotificationEvent,
    BHMDidReceiveLocalNotificationEvent,
    BHMWillContinueUserActivityEvent,
    BHMContinueUserActivityEvent,
    BHMDidFailToContinueUserActivityEvent,
    BHMDidUpdateUserActivityEvent,
    BHMDidCustomEvent = 1000
};
NS_ASSUME_NONNULL_BEGIN

@interface BHModuleManager : NSObject

+ (instancetype)sharedManager;

- (void)registerDynamicModule:(Class)moduleClass;
- (void)loadLocalModules;
- (void)registedAllModules;
- (void)registedAnnotationModules;
- (void)triggerEvent:(BHModuleEventType)eventType;

@end

NS_ASSUME_NONNULL_END



















