//
//  BHAnnotation.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "BHAnnotation.h"
#import "BHCommon.h"
#include <mach-o/getsect.h>
#include <mach-o/loader.h>
#include <mach-o/dyld.h>
#include <dlfcn.h>
#import <objc/runtime.h>
#import <objc/message.h>
static NSArray<NSString *>* BHReadConfiguration(char *section)
{
    NSMutableArray *configs = [NSMutableArray array];
    Dl_info info;
    dladdr(BHReadConfiguration, &info);
    
#ifndef __LP64__
    const struct mach_header  *mhp = (struct mach_header*)info.dli_fbase;
    unsigned long size =0;
    uint32_t *memory = (uint32_t *)getsectiondata(mhp, "__DATA", section, & size);
#else
    const struct mach_header_64 *mhp = (struct mach_header_64*)info.dli_fbase;
    unsigned long size = 0;
    uint64_t *memory = (uint64_t *)getsectiondata(mhp, "__DATA", section, & size);
#endif
    for (int idx = 0 ; idx < size/sizeof(void *); ++idx) {
        char *string = (char *)memory[idx];
        
        NSString *str = [NSString stringWithUTF8String:string];
        if (!str)  continue;
        
        BHLog(@"config = %@", str);
        if(str) [configs addObject:str];
    }
    return configs;
}

@implementation BHAnnotation

+ (NSArray<NSString *> *)AnnotationModules
{
    static NSArray<NSString *> *mods = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mods = BHReadConfiguration(BeehiveModSectName);
    });
    return mods;
}

+ (NSArray<NSString *> *)AnnotationServices
{
    static NSArray<NSString *> *services = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        services = BHReadConfiguration(BeehiveServiceSectName);
    });
    return services;
}



@end






















