//
//  BHCommon.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#ifndef BHCommon_h
#define BHCommon_h

#ifdef DEBUG
#define BHLog(x, ...) NSLog(x, ## __VA_ARGS__);
#else
#define BHLog(x, ...)
#endif


#endif /* BHCommon_h */
