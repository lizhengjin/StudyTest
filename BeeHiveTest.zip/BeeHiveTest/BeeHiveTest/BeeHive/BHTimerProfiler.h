//
//  BHTimerProfiler.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BHTimerProfiler : NSObject

#pragma mark - Open API

#define kTimeProfilerResultNotificationName @"BHTimeProfilerResult"
#define kNotificationUserInfoKey            @"logArray"

+ (BHTimerProfiler *)sharedTimeProfiler;

- (instancetype)initTimeProfilerWithMainKey:(NSString *)mainKey;
- (void)recordEventTime:(NSString *)eventName;

- (void)printOutTimeProfileResult;
- (void)saveTimeProfileDataIntoFile:(NSString *)filePath;
- (void)postTimeProfileResultNotification;

@end

NS_ASSUME_NONNULL_END

















