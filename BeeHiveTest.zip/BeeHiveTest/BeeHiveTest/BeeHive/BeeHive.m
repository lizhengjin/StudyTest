//
//  BeeHive.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "BeeHive.h"

@implementation BeeHive

+ (instancetype)shareInstance
{
    static dispatch_once_t p;
    static id BHInstance = nil;
    dispatch_once(&p, ^{
        BHInstance = [[self alloc] init];
    });
    return BHInstance;
}

+ (void)registerDynamicModule:(Class)moduleClass
{
    [[BHModuleManager sharedManager] registerDynamicModule:moduleClass];
}

- (id)createService:(Protocol *)proto
{
    return  [[BHServiceManager sharedManager] createService:proto];
}

- (void)registerService:(Protocol *)proto service:(Class)serviceClass
{
    [[BHServiceManager sharedManager] registerService:proto implClass:serviceClass];
}

+ (void)triggerCustomEvent:(NSInteger)eventType
{
    if (eventType < 1000) {
        return;
    }
    [[BHModuleManager sharedManager] triggerEvent:eventType];
}

#pragma mark - Private

- (void)setContext:(BHContext *)context
{
    _context = context;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self loadStaticServices];
        [self loadStaticModules];
    });
}
- (void)loadStaticModules
{
    [[BHModuleManager sharedManager] loadLocalModules];
    [[BHModuleManager sharedManager] registedAnnotationModules];
    [[BHModuleManager sharedManager] registedAllModules];
}

- (void)loadStaticServices
{
    [BHServiceManager sharedManager].enableException = self.enableException;
    [[BHServiceManager sharedManager] registerLocalServices];
    [[BHServiceManager sharedManager] registerAnnotationServices];
}
@end












