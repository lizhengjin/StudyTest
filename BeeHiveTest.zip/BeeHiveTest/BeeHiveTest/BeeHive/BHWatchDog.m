//
//  BHWatchDog.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "BHWatchDog.h"

@implementation BHWatchDog

@end
