//
//  BHContext.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BHServiceProtocol.h"
#import "BHConfig.h"
#import "BHAppDelegate.h"
NS_ASSUME_NONNULL_BEGIN

typedef enum
{
    BHEnvironmentDev = 0,
    BHEnvironmentTest,
    BHEnvironmentStage,
    BHEnvironmentProd
}BHEnvironmentType;

@interface BHContext : NSObject

@property (nonatomic, assign) BHEnvironmentType env;

@property (nonatomic, strong) BHConfig *config;
@property (nonatomic, strong) NSString *appkey;
@property (nonatomic, assign) NSInteger customEvent;
@property (nonatomic, strong) UIApplication *application;
@property (nonatomic, strong) NSDictionary *launchOptions;
@property (nonatomic, strong) NSString     *moduleConfigName;
@property (nonatomic, strong) NSString     *serviceConfigName;

#if __IPHONE_OS_VERSION_MAX_ALLOWED > 80400
@property (nonatomic, strong) BHShortcutItem *touchShortcutItem;
#endif

@property (nonatomic, strong) BHOpenURLItem *openURLItem;

@property (nonatomic, strong) BHNotificationsItem *notificationsItem;

@property (nonatomic, strong) BHUserActivityItem  *userActivityItem;

+ (instancetype)shareInstance;
- (void)addServiceWithImplInstance:(id)implInstance serviceName:(NSString *)serviceName;

- (id)getServiceInstanceFromServiceName:(NSString *)serviceName;


@end

NS_ASSUME_NONNULL_END





















