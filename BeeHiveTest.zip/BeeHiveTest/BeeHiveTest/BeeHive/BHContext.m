//
//  BHContext.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "BHContext.h"
@interface BHContext()
@property (nonatomic, strong) NSMutableDictionary *modulesByName;
@property (nonatomic, strong) NSMutableDictionary *servicesByName;
@end
@implementation BHContext

+ (instancetype)shareInstance
{
    static dispatch_once_t p;
    static id BHInstance = nil;
    dispatch_once(&p, ^{
        BHInstance = [[[self class] alloc] init];
        if ([BHInstance isKindOfClass:[BHContext class]]) {
            ((BHContext *)BHInstance).config = [BHConfig shareInstance];
        }
    });
    return BHInstance;
}

- (void)addServiceWithImplInstance:(id)implInstance serviceName:(NSString *)serviceName
{
    [[BHContext shareInstance].servicesByName setObject:implInstance forKey:serviceName];
}

- (id)getServiceInstanceFromServiceName:(NSString *)serviceName
{
    return [[BHContext shareInstance].servicesByName objectForKey:serviceName];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.modulesByName = [[NSMutableDictionary alloc] initWithCapacity:1];
        self.servicesByName = [[NSMutableDictionary alloc] initWithCapacity:1];
        self.moduleConfigName = @"BeeHive.bundle/BeeHive";
        self.serviceConfigName = @"BeeHive.bundle/BHService";
#if __IPHONE_OS_VERSION_MAX_ALLOWED > 80400
        self.touchShortcutItem = [BHShortcutItem new];
#endif
        self.openURLItem = [BHOpenURLItem new];
        self.notificationsItem = [BHNotificationsItem new];
        self.userActivityItem = [BHUserActivityItem new];
    }
    return self;
}

@end




















