//
//  BHServiceManager.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BHContext;
NS_ASSUME_NONNULL_BEGIN

@interface BHServiceManager : NSObject

@property (nonatomic, assign) BOOL enableException;

+ (instancetype)sharedManager;
- (void)registerLocalServices;
- (void)registerAnnotationServices;
- (void)registerService:(Protocol *)service implClass:(Class)implClass;
- (id)createService:(Protocol *)service;

@end

NS_ASSUME_NONNULL_END














