//
//  BHDefines.h
//  BeeHiveTest
//
//  Created by liqi on 2019/5/13.
//  Copyright © 2019年 zhht. All rights reserved.
//

#ifndef BHDefines_h
#define BHDefines_h

#if defined(__cplusplus)
#define BH_EXTERN extern "C"  __attribute__((visibility("default")))
#else
#define BH_EXTERN extern __attribute__((visibility("default")))
#endif


#endif /* BHDefines_h */



















