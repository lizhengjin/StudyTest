//
//  UserTrackModule.m
//  BeeHiveTest
//
//  Created by liqi on 2019/5/16.
//  Copyright © 2019年 zhht. All rights reserved.
//

#import "UserTrackModule.h"
#import "BeeHive.h"
#import "BHService.h"
#import "BHUserTrackViewController.h"

@interface UserTrackModule()<BHModuleProtocol>


@end

@implementation UserTrackModule
BH_EXPORT_MODULE(NO)

- (void)modSetUp:(BHContext *)context
{
    NSLog(@"UserTrackModule  setup----");
}

- (void)modInit:(BHContext *)context
{
    [[BeeHive shareInstance] registerService:@protocol(UserTrackServiceProtocol) service:[BHUserTrackViewController class]];
}


@end













